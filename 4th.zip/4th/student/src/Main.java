import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {
	public static void main(String[] args) throws IOException {
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		Set<Course> courseSet=new TreeSet<Course>(new CourseComparator());
		CourseDAO coursedao =new CourseDAO();
		Student student =new Student();
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		String sname;
		int i;
		Course course1=new Course();
		course1.setCourseName("Hibernate");
		courseSet.add(course1);
		Course course2=new Course();
		course2.setCourseName("WebServices");
		courseSet.add(course2);
		
		System.out.println("Enter Details of 3 Students");
		for(i=1;i<=3;i++)
		{
			System.out.println("Enter the Student "+i+" Details");
			System.out.println("Enter the Student name");
			sname=bf.readLine();
			student.setStudentName(sname);
			
			insertStudent(student,courseSet);

		}
				displayCourseListEnrolledByStudents();
	}

	private static void displayCourseListEnrolledByStudents() {
		Session session=null;
		 session = HibernateUtil.getSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			System.out.println("Course details");
			
			
			List<Student> studentsList =session.createQuery("FROM Student").list(); 
			Iterator it=studentsList.iterator();
			System.out.println("Student Details");
			while(it.hasNext())
			{
				Student studentInstance1= (Student)it.next();
				System.out.println("Student id: "+studentInstance1.getStudentId());
				System.out.println("Student name : "+studentInstance1.getStudentName());
				Set<Course> courses1=studentInstance1.getCourses();
				Iterator it1=courses1.iterator();
				System.out.println("Courses Assigned");
				while(it1.hasNext())
				{
					Course course1=(Course)it1.next();
					System.out.println(course1.getCourseName());
				}
				
			}
			
	}

	private static void insertStudent(Student student, Set<Course> course) {
		 
		Session session = null;
		try {
       session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		//Fill your Code here
		session.save(student);
		//session.save(course);
		
		
		trans.commit();
		session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		
		
		
		
			
			
	}

	
}
