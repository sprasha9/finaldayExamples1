import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main
{
	public static void main(String args[])throws IOException
	
	{
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int i,n;
		
		ProductDAO prodao =new ProductDAO();
		System.out.println("Enter Number of Products");
		n=Integer.parseInt(br.readLine());
		for(i=1;i<=n;i++)
		{
			Product prod=new Product();
			System.out.println("Enter Product "+i+" Details");
			System.out.println("Enter Product Name : ");
			prod.setName(br.readLine());
			System.out.println("Enter Product Category : ");
			prod.setCategory(br.readLine());
			System.out.println("Enter Product Price : ");
			prod.setPrice(Integer.parseInt(br.readLine()));
			System.out.println("Enter Product Stock : ");
			prod.setStock(Integer.parseInt(br.readLine()));
			prodao.insertProducts(prod);
		}
		List<Product> productList=prodao.displayProducts();
		Iterator it=productList.iterator();
		while(it.hasNext())
		{
			Product p=(Product)it.next();
			System.out.println("\nProduct Id : "+p.getId());
			System.out.println("Name     : "+p.getName());
			System.out.println("Category : "+p.getCategory());
			System.out.println("Price    : "+p.getPrice());
			System.out.println("Stock    : "+p.getStock());
		}
		
	}
}