import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;

public class ProductDAO {
	public void insertProducts(Product product)
	{
		Session session1=HibernateUtil.getSessionFactory().openSession();
		session1.save(product);
		session1.close();
	}
	
	
	
	public List<Product> displayProducts(){
		Session session = null;
		//Complete the code using Criteria, Criterion and Restrictions API
//fill code here
		session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Product p=new Product();
		Criteria criteria=session.createCriteria(Product.class);
		criteria.add(Restrictions.le("price", 100)).add(Restrictions.eq("category","Groceries" ));
		List list=criteria.list();
		Iterator it=list.iterator();
		while (it.hasNext()) {
		Product product = (Product) it.next();
		/*System.out.println("Product Id"+product.getId());
		System.out.println("Name"+product.getName());
		System.out.println("Category"+product.getCategory());
		System.out.println("Price"+product.getPrice());
		System.out.println("Stock"+product.getStock());*/
		}
		return list;
	}
}
