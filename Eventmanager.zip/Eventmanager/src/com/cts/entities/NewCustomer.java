package com.cts.entities;

public class NewCustomer extends Customer{

}
