package com.cts.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Customer;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class Locationmanager {
	private static SessionFactory factory;
 	private static Session session;
 	private static boolean status;

 	public static boolean AddLocation(Location location)
 	{
 		factory=HibernateUtil.GetFactory();
 		session=factory.openSession();
 		session.beginTransaction();
 		try{
 			session.save(location);
 			session.getTransaction().commit();
 			status=true;
 		}catch(HibernateException hib)
 		{
 			session.getTransaction().rollback();
 		}
 		session.close();
 		return status;
 	}
 	
 	
 	
 	
 	public static List<Location> getAll()
 	{
 		factory=HibernateUtil.GetFactory();
 		session=factory.openSession();
 		return session.createQuery("from Location").list();
 	}
 	
}
