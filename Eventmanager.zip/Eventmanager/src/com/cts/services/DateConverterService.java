package com.cts.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.SimpleFormatter;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
@Path("/dateconveter")
public class DateConverterService {
	
	@GET
	@Path("/format/{year}/{month}/{day}")
	public Response FormDate(@PathParam("year")int year,@PathParam("month")int month,@PathParam("day")int day)
	{
		SimpleDateFormat formater=new SimpleDateFormat("yy/MMM/dd"); 
		Date date=new Date(year,month,day);
		String fdate=formater.format(date);
		return Response
				 .status(200)
	          .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(fdate)
		            .build();
	}

}
