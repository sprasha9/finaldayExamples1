package com.cts.services;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.cts.entities.Message;

@Path("/productservice")
public class ProductService {
@Path("/addproduct")
@POST
	public Response addproduct(@FormParam("productid")int productid,@FormParam("productname")String productname)
	{
	Message m=new Message();
	if((productid>0)&&(productname!=null))
			{
		System.out.println(productid+productname);
		m.setStatus("the data is"+productid+"nameis"+productname);
			}
		return Response
				 .status(200)
	          .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(m)
		            .build();
	}
	
	
	
	
}
