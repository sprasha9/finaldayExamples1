import javax.persistence.*;
//fill the code
@Entity 
@DiscriminatorValue(value = "N")
public class NewCustomer extends Customer{
	

}
