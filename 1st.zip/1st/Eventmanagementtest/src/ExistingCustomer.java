import javax.persistence.*; 
//fill the code
@Entity 
@DiscriminatorValue( value="E")
public class ExistingCustomer extends Customer{
	
	
}
