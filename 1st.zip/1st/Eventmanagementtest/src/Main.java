import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class Main {
public static void main(String args[]) throws IOException{
	Logger log = Logger.getLogger("org.hibernate");
    log.setLevel(Level.OFF);
	System.setProperty("org.apache.commons.logging.Log",
			"org.apache.commons.logging.impl.NoOpLog");
	BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
	String nCustomerName,eCustomerName,nCustomerAdd,eCustomerAdd;
	int cid,cid1;
	System.out.println("Enter the New Customer Details");
	System.out.println("Enter the Customer id");
	cid=Integer.parseInt(bf.readLine());
	System.out.println("Enter the name");
	nCustomerName=bf.readLine();
	System.out.println("Enter the address");
	nCustomerAdd=bf.readLine();
	System.out.println("Enter the Existing Customer Details");
	System.out.println("Enter the Customer id");
	cid1=Integer.parseInt(bf.readLine());
	System.out.println("Enter the name");
	eCustomerName=bf.readLine();
	System.out.println("Enter the address");
	eCustomerAdd=bf.readLine();
	NewCustomer nc=new NewCustomer();
	nc.setId(cid);
	nc.setName(nCustomerName);
	nc.setCustAddress(nCustomerAdd);
	ExistingCustomer ec=new ExistingCustomer();
	ec.setName(eCustomerName);
	ec.setCustAddress(eCustomerAdd);
	ec.setId(cid1);
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	Transaction trans = session.beginTransaction();
	 session.persist(ec); 
	 session.persist(nc); 
	 System.out.println("Customer Details");
	try {
		
		List<Customer> customer = (List<Customer>) session.createQuery("from Customer as c ORDER BY c.id").list();
		if (customer!=null) {
			for (Customer c : customer) {
				 System.out.println(c.getId() + " - " + c.getName());
			}
		}
		session.getTransaction().commit();
	}
	catch (HibernateException e) {
		e.printStackTrace();
		session.getTransaction().rollback();
	}
}
}
