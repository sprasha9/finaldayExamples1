import javax.persistence.*;  
//fill the code
@Entity 
@Table(name="Customer_v1")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE) 
@DiscriminatorColumn(name="type", discriminatorType = DiscriminatorType.STRING)
public class Customer {
	//fill the code
	@Id
	@Column(name="cust_id")
	private int id;
	
	//fill the code
	@Column(name="cust_name")
	private String name;
	
	//fill the code
	@Column(name="cust_address")
	private String custAddress;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	} 

}
