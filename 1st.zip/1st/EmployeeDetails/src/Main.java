import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main{
	
	public static void main(String[] args) {
		
	Logger log = Logger.getLogger("org.hibernate");
        log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
				// fill the code
		
		
		SessionFactory factory=HibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Transaction trans = session.beginTransaction();
		List<Employee> test=null;
		Query query= (Query) session.createQuery("from Employee");
		test=query.list();
		for(Employee employee:test)
		{
	
			 System.out.println(employee.getId()+"-"+employee.getName());	
		}
		trans.commit();
	}

}








