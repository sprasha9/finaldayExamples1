
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class BookDAO {
	
	public void addDetails(Book book)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		try {

        
		session.save(book);
		trans.commit();
		session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			trans.rollback();
		}
	}
	public List<Book> listDetails(){
		Session session = null;
		List<Book> booklist = new ArrayList<Book>();
		try {
			 session = HibernateUtil.getSessionFactory().openSession();
				Transaction trans = session.beginTransaction();
				booklist = session.createQuery("FROM Book").list(); 
				
			
		
		trans.commit();
		session.close();
		
		
		} catch (HibernateException e) {
			e.printStackTrace();
			session.beginTransaction().rollback();
		}
		return booklist;
	}

}
