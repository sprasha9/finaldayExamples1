import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;


public class Main {
	
public static void main(String args[]) throws NumberFormatException, IOException{
	Logger log = Logger.getLogger("org.hibernate");
    log.setLevel(Level.OFF);
	System.setProperty("org.apache.commons.logging.Log",
			"org.apache.commons.logging.impl.NoOpLog");
	getAllEmployees();
	BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
	Integer eid; 
	System.out.println("Enter the employee id to display the details");
	eid=Integer.parseInt(bf.readLine());
	getEmployeewithID(eid);
	System.out.println("Update Employee's Name");
	System.out.println("Enter the id");
	int id=Integer.parseInt(bf.readLine());
	System.out.println("Enter the employee name");
	String ename=bf.readLine();
	updateEmployee(id,ename);
	System.out.println("After Update");
	getAllEmployees();
    System.out.println("First Five Employees:");
	listOnlyTheFirstFiveEmployees();
	System.out.println("Employee's Address Details");
	listEmployeeDetailsWithAddress();
}


private static void listOnlyTheFirstFiveEmployees() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	
	//fill the code
	Transaction trans = session.beginTransaction();
	
	Criteria criteria=session.createCriteria(Employee.class);
	criteria.setFirstResult(0);
	criteria.setMaxResults(5);
	List<Employee> empList=criteria.list();
       System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));
       for(Employee emp : empList){
    	   System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
       }
       trans.commit();
	session.close();
	
	
}


private static void getEmployeewithID(int id) {
	
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	//fill the code
	Transaction trans = session.beginTransaction();
	Employee emp=(Employee)session.get(Employee.class, id);
    System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));
    System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
   
    trans.commit();
    session.close();
	
}


private static void getAllEmployees() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	Transaction trans = session.beginTransaction();
	//fill the code
	List<Employee> empList=(List<Employee>)session.createQuery("from Employee").list();
	 System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));

	for(Employee emp : empList){
    	System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
	}
    trans.commit();
    session.close();
}         


private static void updateEmployee(int id, String name) {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	//fill the code
	Employee emp=(Employee) session.get(Employee.class,id);
	emp.setName(name);
	Transaction trans = session.beginTransaction();
	//System.out.println("Employee Update Status="+result);
	trans.commit();
session.close();
}


private static void listEmployeeDetailsWithAddress() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	Transaction trans = session.beginTransaction();
	//fill the code
	
	Query query=session.createQuery("select emp.name,adr.city from Employee emp inner join emp.address adr");
	List<Object[]> list=query.list();
       /* List<Employee> query=session.createQuery("from Employee").list();
        for(Employee emp:query)
        {
        	
        	System.out.println(emp.getAddress().getCity());
        }*/
    	for(Object[] arr : list){
	            System.out.println(Arrays.toString(arr));
	 }
        
    	trans.commit();
	session.close();

}

}







