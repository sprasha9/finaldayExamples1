import javax.persistence.Cacheable;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;




	@Cacheable
	@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
	public class Employee{
		private int id;
		private String name;
		public void setId(int id)
		{
			this.id=id;
		}
		public void setName(String name)
		{
			this.name=name;
		}
		public int getId()
		{
			return this.id;
		}
		public String getName()
		{
			return this.name;
		}
    }
