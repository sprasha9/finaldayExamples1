import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class OrderDAO {
	public void addDetails(CustomerOrder order)
	{
		Session session = null;
		try {

        session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(order);
		trans.commit();
		session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			session.beginTransaction().rollback();
		}
	}
	
public List<CustomerOrder> listDetails()
{
	Session session = null;
	List<CustomerOrder> orderlist = new ArrayList<CustomerOrder>();
	try {
		 session = HibernateUtil.getSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			orderlist = session.createQuery("FROM CustomerOrder").list(); 
			
		
	
	trans.commit();
	session.close();
	
	
	} catch (HibernateException e) {
		e.printStackTrace();
		session.beginTransaction().rollback();
	}
	return orderlist;
}

}
