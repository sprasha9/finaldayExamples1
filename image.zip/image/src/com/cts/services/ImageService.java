package com.cts.services;

import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
@Path("/imageservice")
public class ImageService {
	
	
	
	@GET
	public Response Downloadimage()
	{
		File file=new File("C:/Users/Public/Pictures/Sample Pictures/Penguins.jpg");
		
		return Response
				 .status(200)
	            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity((Object)file)
		            .build();
	}
	
	
	
	
	@GET
	@Path("/get/{eventid}")
	@Produces("text/plain")
	public Response getdata(@PathParam("eventid")int eventid,@MatrixParam("eventname")String eventname)
	{
		String eve=eventname+""+eventid;
		return Response.ok().entity(eve).cookie(new NewCookie("cookieresponse",eve)).build();
		/*return Response
				 .status(200)
	            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(eve)
		            .build();	*/
	}

}
