package com.cognizantacademy;

import java.io.IOException;
import java.util.List;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


public class PetStoreService {

 // Store Customer details   
	@Path("storeCustomerDetails")
	@POST
	public void storeCustomerDetails(
	@FormParam("cust_no") Integer strCustNo,
	@FormParam("cust_name") String strCustName,
	@FormParam("house_no") String strHouseNo,
	@FormParam("Street") String strStreet,
	@FormParam("City") String strCity,
	@FormParam("State") String strState,
	@FormParam("Pin_Code") String strPinCode,
	@FormParam("Contact_No") String strContctNo,
	@FormParam("Email_Id") String strEmailId
	
	) throws ClassNotFoundException, IOException
	{
		CustomerDAO customerdao = new CustomerDAO ();
		
		Customer customer =new Customer(strCustNo, strCustName, strHouseNo, strStreet, strCity, strState, strPinCode, strContctNo, strEmailId);
		customerdao.storeCustomerDetails(customer);
	}
	
	// enroll membershipcard
	
		@Path("enrollForMemberShipCard")
		@POST
		public void enrollForMemberShipCard(
		@FormParam("cust_no") Integer strCustNo,
		@FormParam("cust_card_no") Integer strCardNo,
		@FormParam("points_Earned") Integer PointsEarned)
		{
		
		MemberShipCardDAO membershipcarddao =  new MemberShipCardDAO();
		MemberShipCard membershipcard=new MemberShipCard(strCardNo, strCardNo, PointsEarned);
		membershipcarddao.enrollForMemberShipCard(strCustNo,membershipcard);

	   }
		
		// petdetails
		
		@Path("createPet")
		@POST
		public void  createPet(
		@FormParam("pet_id") Integer IntPetid,
		@FormParam("pet_name") String strPetname)
		{
		
			PetDAO ptdao =  new PetDAO();
			Pet pet=new Pet(IntPetid, strPetname);
			ptdao.createPet(pet);

	   }
		
		// petorder
		
				@Path("createOrder")
				@POST
				public void  createOrder(
				@FormParam("order_id") Integer Intorderid,
				@FormParam("order_date") String strorderdate,
				@FormParam("total_amount") Integer totalamt,
				@FormParam("cust_no") Integer strCustNo,
				@FormParam("sales_boyId") Integer salesboyid)
				{
				OrderDAO ordrdao =  new OrderDAO();
				ordrdao.createOrder(Intorderid, strorderdate,totalamt,strCustNo,salesboyid);

			   }
	
				
        // petorderdetails				
				
				
				@Path("createOrderDetail")
				@POST
				public void  createOrderDetail(
				@FormParam("order_id") Integer Intorderid,
				@FormParam("pet_id") Integer IntPetid,
				@FormParam("Quantity") Integer IntQuantity,
				@FormParam("Price") Integer IntPrice)
				{
				
					OrderDtlsDAO ordrdtlsdao =  new OrderDtlsDAO();
					ordrdtlsdao.createOrderDetail(Intorderid, IntPetid,IntQuantity,IntPrice);

			   }
		

				
// Assign the PetOrder to SalesBoy			
				
				
			/*	@Path("assignOrderToSalesBoy")
				@POST
				public void  assignOrderToSalesBoy(
				@FormParam("Sales_BoyId") Integer IntSalesboyid,
				@FormParam("Sales_BoyName") String strboyname,
				@FormParam("Address") String straddress,
				@FormParam("Contact_No") Integer Intcontactno,
				@FormParam("Email_Id") String stremailid)
							
				{
				
					SalesBoyDAO salesboyDAO =  new SalesBoyDAO();
					salesboyDAO.assignOrderToSalesBoy(IntSalesboyid, strboyname,straddress,Intcontactno,stremailid);

			   }
			
				
// findTotalDeliveryMadeByEachSalesBoy		
				
				
				@Path("assignOrderToSalesBoy")
				@POST
				public void  assignOrderToSalesBoy(
				@FormParam("Sales_BoyId") Integer IntSalesboyid,
				@FormParam("Sales_BoyName") String strboyname,
				@FormParam("Address") String straddress,
				@FormParam("Contact_No") Integer Intcontactno,
				@FormParam("Email_Id") String stremailid)
							
				{
				
					SalesBoyDAO salesboyDAO =  new SalesBoyDAO();
					salesboyDAO.assignOrderToSalesBoy(IntSalesboyid, strboyname,straddress,Intcontactno,stremailid);

			   }*/
				
}



