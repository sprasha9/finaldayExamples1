package com.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("/helloworld")
public class Helloworld {
	
	//fill the code
	@GET
	 @Produces("text/plain")
	@Path("/plain")
	public String sayPlainTextHello() {
		return "Hello World RESTful Jersey!";
	}
	
	//fill the code
	@GET
	@Path("/xml")
	  @Produces("text/xml")  
	public String sayXMLHello() {
		return "<?xml version=\"1.0\"?>" + "<hello> Hello World RESTful Jersey"
				+ "</hello>";
	}

      //fill the code
	@GET
@Path("/html")
	  @Produces("text/html") 
	public String sayHtmlHello() {
		return "<html> " + "<title>" + "Hello World RESTful Jersey"
				+ "</title>" + "<body><h1>" + "Hello World RESTful Jersey"
				+ "</body></h1>" + "</html> ";
	}
}
