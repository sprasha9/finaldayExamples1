package com.rest;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/UserService")
public class UserService {
	 static List<User> userList = new ArrayList<User>();
   public UserService() {
		super();
		// TODO Auto-generated constructor stub
	}
   
   void createUserList(){
	   userList.add(new User(1, "Madhu", "Teacher","madhu@gmail.com"));
	   userList.add(new User(2, "Sri", "Student","sri1@gamil.com"));
	   userList.add(new User(3, "Haritha", "Student","haritha12@gamil.com"));
	   userList.add(new User(4, "Priya", "Teacher","priya@gamil.com"));
	   userList.add(new User(5, "Poorna", "Student","poorna@gamil.com"));
	   userList.add(new User(6, "Dharani", "Teacher","dharani12@gamil.com"));
   }





//fill the code
   @GET
   @Path("users/{userid}")
   @Produces("/xml")
   public User getUserById(@PathParam("userid") int userid) throws IOException, ClassNotFoundException{
		createUserList();
      // User user=new User();
       User user=userList.get(userid);
		return user ;
     //fill the code
   }	
	
	
//fill the code
   @GET
	@Path("/plain/{username}")
	@Produces("text/plain")
   public Response getUserByUserName(@PathParam("username") String username) throws IOException, ClassNotFoundException{
		createUserList();
      //fill the code
		return Response
				   .status(200).entity(username).build();
   }
	
	
	
}
