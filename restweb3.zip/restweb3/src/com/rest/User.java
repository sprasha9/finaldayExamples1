package com.rest;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "user")
public class User implements Serializable {

   private static final long serialVersionUID = 1L;
   private int id;
   private String email;
   private String name;
   private String profession;
   
   public User(){}
   public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

 


   
   public User(int id, String name, String profession,String email){
      this.id = id;
      this.name = name;
      this.profession = profession;
      this.email=email;
   }

   public int getId() {
      return id;
   }

   @XmlElement
   public void setId(int id) {
      this.id = id;
   }
   public String getName() {
      return name;
   }
   @XmlElement
   public void setName(String name) {
      this.name = name;
   }
   public String getProfession() {
      return profession;
   }
   @XmlElement
   public void setProfession(String profession) {
      this.profession = profession;
   }		
}
