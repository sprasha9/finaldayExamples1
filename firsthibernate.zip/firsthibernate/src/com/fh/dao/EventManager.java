package com.fh.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.fh.entity.Event;
import com.fh.resources.HibernateUtil;

public class EventManager {

	
	private SessionFactory factory;
	public EventManager()
	{
		factory=HibernateUtil.GetFactory();
		
	}
	public boolean AddEvent(Event event)
	{
	boolean status=false;
	Session session = factory.openSession();
	session.beginTransaction();
	
	
	
	try
	{
		session.save(event);
		session.getTransaction().commit();
	}catch(HibernateException ex)
	{
		session.getTransaction().rollback();
	}
	return status;
	}
}
