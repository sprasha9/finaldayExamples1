package com.fh.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.fh.entity.Room;
import com.fh.resources.HibernateUtil;


public class RoomManager {

	private SessionFactory factory; 
	private Session session;
	
	public boolean AddRoom(Room room)
	{
		boolean status=false;
		factory=HibernateUtil.GetFactory();
	
		session=factory.openSession();
		session.beginTransaction();
		try
		{
		session.save(room);
		session.getTransaction().commit();
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	
	public boolean updateroom(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		Room room=(Room)session.get(Room.class,roomNo);
		
		
		room.setCapacity(55);
		
		session.beginTransaction();
		
		try
		{
			session.update(room);
			
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		
		session.close();
		return status;
	}

	public boolean roomevict(int roomNo1,int roomNo2)
	{
		boolean status=false;
		session=factory.openSession();
		Room obj1=(Room) session.get(Room.class, roomNo1);
		Room obj2=(Room) session.get(Room.class, roomNo2);
		
		
		
		session.evict(obj2);
		obj1.setCapacity(255);
		obj2.setCapacity(100);
		session.getTransaction().commit();
		session.close();
		return status;
	}
	
	
	
	public boolean SessionClose(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		Room room=(Room)session.get(Room.class,roomNo);
		session.beginTransaction();
		session.close();
		room.setCapacity(67);
		
		Session session1=factory.openSession();
		Room room1=(Room)session.get(Room.class,roomNo);
		session1.merge(room);
		session1.getTransaction().commit();
		status=true;
		return status;
	}
}
