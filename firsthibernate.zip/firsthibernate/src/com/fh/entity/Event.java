package com.fh.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Event")
public class Event {

	@EmbeddedId
	private   Eventkey eventid;
	@Column(name="eventname")
	private String eventname;
	@Column(name="location")
	private String location;
	@Column(name="duration")
	private String duration;
	public Eventkey getEventid() {
		return eventid;
	}
	public void setEventid(Eventkey eventid) {
		this.eventid = eventid;
	}
	public String getEventname() {
		return eventname;
	}
	public void setEventname(String eventname) {
		this.eventname = eventname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	
	
}
