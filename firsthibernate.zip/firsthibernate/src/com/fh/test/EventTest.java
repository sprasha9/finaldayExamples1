package com.fh.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.fh.dao.EventManager;
import com.fh.entity.Event;
import com.fh.entity.Eventkey;

public class EventTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		EventManager em=new EventManager();
        
        Eventkey key=new Eventkey();
        key.setEventid(3);
        key.setTrainerid(63);
        
        
        Event event=new Event();
        event.setEventid(key);
        event.setDuration("16");
        event.setEventname("decoration");
        event.setLocation("asv");
        
        assertTrue(em.AddEvent(event));
	}

}
