package com.fh.utility;

import java.util.Scanner;

import com.fh.dao.EventManager;
import com.fh.dao.RoomManager;
import com.fh.entity.Event;
import com.fh.entity.Eventkey;
import com.fh.entity.Room;

public class TestApp {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
           /* RoomManager roomManager =new RoomManager();
            Room room =new Room();
            room.setCapacity(25);
            room.setLocation("ASV Sun Tech");
            room.setProjector_Avl(true);
            room.setSystem_Avl(true);
           //roomManager.AddRoom(room);
            
           // roomManager.updateroom(2);
           
           
           
           Scanner sc=new Scanner(System.in);
           
           int roomno1=sc.nextInt();
           roomManager.SessionClose(roomno1);*/
           
           
           
           /*EventManager em=new EventManager();
           
           Eventkey key=new Eventkey();
           key.setEventid(1);
           key.setTrainerid(12);
           
           
           Event event=new Event();
           event.setEventid(key);
           event.setDuration("12");
           event.setEventname("decoration");
           event.setLocation("asv");
           
           em.AddEvent(event);*/
		String h="";
		String m="null";
		System.out.println(h+m);
		System.out.println("10.1234");
		      
	}

	
	
}
