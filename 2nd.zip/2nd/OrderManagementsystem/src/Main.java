import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Main
{
	public static void main(String args[])throws IOException,ParseException
	
	{
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int i,n;
		SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd");
		OrderDAO orderdao =new OrderDAO();
		System.out.println("Enter Number of Orders");
		n=Integer.parseInt(br.readLine());
		for(i=1;i<=n;i++)
		{
			Order order=new Order();
			System.out.println("Enter Order "+i+" Details");
			System.out.println("Enter Order Date : ");
			String date=br.readLine();
			order.setOrderDate(s.parse(date));
			System.out.println("Enter Order Amount : ");
			order.setAmount(Float.parseFloat(br.readLine()));
			
			orderdao.insertOrders(order);
		}
		System.out.println("Enter a date");
		orderdao.listOrdersForParticularDate(s.parse(br.readLine()));
		
	}
}