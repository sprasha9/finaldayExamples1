import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.SequenceGenerator;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


import javax.persistence.Cacheable;
 
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;	

import java.util.Date;

@Entity
@Table(name="ORDERLIST")
public class Order{
	@Id
	@Column(name="ORDER_ID",nullable=false)
	//@SequenceGenerator(name="orderid_seq", sequenceName="order_id_seq_v", initialValue=1)
	//@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="orderid_seq")
	private int orderId;
	
	@Column(name="AMOUNT")
	private float amount;
	
	@Column(name="ORDERDATE")
	@Temporal(TemporalType.DATE)
	private Date orderDate;
	
	public Order()
	{
		
	}
	public Order(Date orderDate,float amount)
	{
		//this.orderId=orderId;
		this.orderDate = orderDate;
		this.amount = amount;
	}
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
/*	@Transient
	public int getId() {
		return this.orderId;
	}

	@Transient
	public String getLogDetail() {
		StringBuilder sb = new StringBuilder();
		sb.append("Order Id :").append(orderId)
		.append("Amount :").append(amount)
		.append("Order Date :").append(orderDate);
		return sb.toString();
	}
	*/
}
