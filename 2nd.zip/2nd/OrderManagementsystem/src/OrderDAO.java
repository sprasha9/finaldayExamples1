import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class OrderDAO {
	
	public void insertOrders(Order order)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.save(order);
		session.close();
	}

	public void listOrdersForParticularDate(java.util.Date orderDate1){
		Session session = null;
		try{
			session = HibernateUtil.getSessionFactory().openSession();
		//fill code
			/*Criteria criteria=session.createCriteria(Order.class);
			
criteria.add(Restrictions.eq("date1","orderDate"));
List<Order> order=criteria.list();

SimpleDateFormat formater=new SimpleDateFormat("yyyy-MM-dd"); 
Date date=new Date(orderDate1.getDate());
String fdate=formater.format(date);

for(Order ord:order)
{
	ord.getOrderId();
	ord.getAmount();
	ord.getOrderDate();
}*/
			session.beginTransaction();
			SimpleDateFormat DateFormat=new SimpleDateFormat("yyyy-MM-dd");
			DateFormat.format(orderDate1);
			Criteria criteria=session.createCriteria(Order.class);
			criteria.add(Restrictions.eq("orderDate", orderDate1));
			
			/*criteria.add(Restrictions.eqProperty("orderDate", orderDate1));*/
			
				List<Order>l=criteria.list();
				Iterator<Order>it=l.iterator();
				String str=null;
				while(it.hasNext()) {
				Order order = (Order) it.next();
				str=DateFormat.format(order.getOrderDate());
				System.out.println("ORDER_ID"+"\t"+"AMOUNT"+"\t"+"ORDER_DATE");
				System.out.println(order.getOrderId()+"\t"+order.getAmount()+"\t"+str);
				}

		}
		catch(HibernateException e){
			System.out.println("Inside exception in the query listOrderforParticularDate"+e.getMessage());
		}
		finally{
			session.close();
		}
	}
}
