import java.sql.Connection;
import java.util.Date;

import org.hibernate.Session;


public class AuditLogUtil {
	public static void LogIt(String action,
		     AuditLogInterface entity, Connection conn ){
				
		Session tempSession = HibernateUtil.getSessionFactory().openSession();
					
		     try {

			AuditLog auditRecord = new AuditLog(action
				,entity.getId(), entity.getClass().toString());
			tempSession.save(auditRecord);
			tempSession.flush();
					
		     } finally {	
			tempSession.close();		
		     }		
		  }
}
