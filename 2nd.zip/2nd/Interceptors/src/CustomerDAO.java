import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CustomerDAO {
	public void addDetails(Customer customer,Set<Order> orderSet)
	{
		Session session = null;
		Transaction trans=null;
		try {

			 session = HibernateUtil.getSessionFactory().withOptions()
		               .interceptor(new AuditLogInterceptor())
		               .openSession();
		trans = session.beginTransaction();
		customer.setOrder(orderSet);
		session.save(customer);
		trans.commit();
		
		} catch (HibernateException e) {
			if (trans!=null) trans.rollback();
			e.printStackTrace();
			System.out.println("not able to insert");
			
		}
		finally
		{
			session.close();
		}
	}
	
public List<Customer> listDetails()
{
	Session session = null;
	Transaction trans=null;
	   session = HibernateUtil.getSessionFactory().withOptions()
               .interceptor(new AuditLogInterceptor())
               .openSession();
	
	List<Customer> customerlist;
	try {
		 session = HibernateUtil.getSessionFactory().openSession();
			trans = session.beginTransaction();
			customerlist = session.createQuery("FROM Customer").list(); 
				
	trans.commit();
	return customerlist;
	
	} catch (HibernateException e) {
		if (trans!=null) trans.rollback();
		e.printStackTrace();
		System.out.println("Not able to retrieve");
		return null;
	}
	finally
	{
		session.close();
	}
	
}

}
