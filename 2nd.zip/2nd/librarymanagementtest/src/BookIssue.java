import java.util.Date;

import javax.persistence.*;
@Entity
@Table(name="BOOK_ISSUE")
public class BookIssue {

	@AttributeOverrides({
		@AttributeOverride(name="custId",column=@Column(name="CUSTOMER_ID")),
		@AttributeOverride(name="bookId",column=@Column(name="BOOK_ID"))
	})
	@EmbeddedId
	private BookIssueId bookIssueId;
	
	@Column(name="ISSUE_DATE")
	private Date bookIssueDate;
	
	@Column(name="DUE_DATE")
	private Date bookDueDate;
	
	@Column(name="RETURN_DATE")
	private Date returnDate;
	
	public BookIssueId getBookIssueId() {
		return bookIssueId;
	}

	public void setBookIssueId(BookIssueId bookIssueId) {
		this.bookIssueId = bookIssueId;
	}

	
	public Date getBookIssueDate() {
		return bookIssueDate;
	}

	public void setBookIssueDate(Date bookIssueDate) {
		this.bookIssueDate = bookIssueDate;
	}

	
	public Date getBookDueDate() {
		return bookDueDate;
	}

	public void setBookDueDate(Date bookDueDate) {
		this.bookDueDate = bookDueDate;
	}

	
	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

}
