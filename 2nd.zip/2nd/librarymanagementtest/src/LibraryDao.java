import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class LibraryDao {
	public void totalBooksIssued(Date currentDate){
		//fill the code
		
		
		SessionFactory factory=HibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Query query=session.createQuery("select count(b.bookIssueId) from BOOK_ISSUE b where b.bookIssueDate=?");
		query.setParameter(0, currentDate);
		
		int totalBooks=(int) query.list().get(0);
			System.out.println("Total Books issued for the month " +totalBooks);
		
}
}
