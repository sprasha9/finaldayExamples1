import javax.persistence.*;
@Entity
@Table(name="BOOK")
public class Book {

	private int bookId;
	
	private String bookName;
	
	private float price;
	
	private int quantityAvailable;

	@Id
	@GeneratedValue
	@Column(name="BOOK_ID")
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	@Column(name="BOOK_NAME")
	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	@Column(name="PRICE")
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Column(name="STOCK")
	public int getQuantityAvailable() {
		return quantityAvailable;
	}

	public void setQuantityAvailable(int quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}
	
	
}

